﻿// import the namespace
using System.Xml;

namespace Ch03_AssembliesAndNamespaces
{
    class Program
    {
        static void Main(string[] args)
        {
            var doc = new XmlDocument();
            var data = new XmlDataDocument();
        }
    }
}
