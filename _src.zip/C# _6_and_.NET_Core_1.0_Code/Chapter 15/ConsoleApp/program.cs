using System;

public class Program
{
    public static void Main()
    {
        Console.WriteLine("Hello C# Cross-Platform!");
    }
}
