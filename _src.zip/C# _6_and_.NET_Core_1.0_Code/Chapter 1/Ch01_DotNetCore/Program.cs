﻿using System;

namespace Ch01_DotNetCore
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Welcome, .NET Core!");
            Console.ReadLine();
        }
    }
}
